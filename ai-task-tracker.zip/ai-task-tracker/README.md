# Taskwise: AI task tracker

A full-stack task tracker (React + Node/Express + MySQL) with accounts and three AI features:

- **Add with AI:** type "Send Sam the budget by Friday, it's urgent" and the LLM extracts the title, priority and due date.
- **Split into steps:** the LLM breaks any task into 3-6 subtasks.
- **Suggest tasks:** the LLM proposes tasks you may be missing, based on your open ones.

Users register and sign in with email and password. Every task belongs to one user and the API only returns that user's rows.

## Run it

Requires Node 20.6+ and Docker (or any MySQL 8 server).

```bash
# 1. database
docker compose up -d

# 2. API
cd server && npm install
cp .env.example .env   # add ANTHROPIC_API_KEY and a random JWT_SECRET
npm run dev            # creates the database and tables on first start

# 3. UI (new terminal)
cd client && npm install && npm run dev
```

Open http://localhost:5173 and create an account.

## Architecture

- `client/`: Vite + React. `/api` calls are proxied to the server. `Auth.jsx` handles register/sign in, `Tasks.jsx` is the app.
- `server/index.js`: routes. `auth.js`: JWT middleware. `tasks.js`: MySQL queries (parameterized, transactional). `db.js`: pool and schema. `ai.js`: prompts and the LLM call.
- Passwords are hashed with bcrypt. Tokens are JWTs that expire after 7 days. The AI key never reaches the browser.

### Schema

`users` 1 → many `tasks` 1 → many `subtasks` (cascade deletes).

## Roadmap

- [ ] Rate limiting on auth and AI routes
- [ ] httpOnly cookie sessions instead of a token in localStorage
- [ ] Tests (Jest + React Testing Library) and GitHub Actions CI
- [ ] TypeScript
- [ ] Deploy with a live demo link
