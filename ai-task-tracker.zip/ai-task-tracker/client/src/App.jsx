import { useCallback, useEffect, useState } from 'react';
import { api } from './api.js';
import Auth from './Auth.jsx';
import Tasks from './Tasks.jsx';

export default function App() {
  const [user, setUser] = useState(null);
  const [ready, setReady] = useState(!api.hasToken());

  const logout = useCallback(() => { api.setToken(null); setUser(null); }, []);

  // Restore the session if a saved token is still valid.
  useEffect(() => {
    if (api.hasToken()) api.me().then((r) => setUser(r.user)).catch(logout).finally(() => setReady(true));
  }, [logout]);

  if (!ready) return null;
  if (user) return <Tasks user={user} onLogout={logout} />;
  return <Auth onAuth={(res) => { api.setToken(res.token); setUser(res.user); }} />;
}
