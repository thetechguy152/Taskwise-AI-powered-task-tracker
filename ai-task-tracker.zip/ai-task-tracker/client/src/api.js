let token = null;
try { token = localStorage.getItem('token'); } catch { /* storage unavailable */ }

function setToken(t) {
  token = t;
  try { t ? localStorage.setItem('token', t) : localStorage.removeItem('token'); } catch { /* ignore */ }
}

async function call(path, options = {}) {
  const res = await fetch(`/api${path}`, {
    ...options,
    headers: { 'content-type': 'application/json', ...(token && { authorization: `Bearer ${token}` }) },
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  if (res.status === 204) return null;
  const data = await res.json();
  if (res.status === 401 && token) api.onUnauthorized?.();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

export const api = {
  onUnauthorized: null,
  hasToken: () => !!token,
  setToken,
  register: (creds) => call('/auth/register', { method: 'POST', body: creds }),
  login: (creds) => call('/auth/login', { method: 'POST', body: creds }),
  me: () => call('/auth/me'),
  list: () => call('/tasks'),
  create: (task) => call('/tasks', { method: 'POST', body: task }),
  update: (id, patch) => call(`/tasks/${id}`, { method: 'PATCH', body: patch }),
  remove: (id) => call(`/tasks/${id}`, { method: 'DELETE' }),
  parse: (text) => call('/ai/parse', { method: 'POST', body: { text } }),
  suggest: () => call('/ai/suggest', { method: 'POST' }),
  breakdown: (title) => call('/ai/breakdown', { method: 'POST', body: { title } }),
};
