import { useEffect, useState } from 'react';
import { api } from './api.js';

const FILTERS = ['all', 'open', 'done'];

export default function Tasks({ user, onLogout }) {
  const [tasks, setTasks] = useState([]);
  const [text, setText] = useState('');
  const [filter, setFilter] = useState('open');
  const [busy, setBusy] = useState(null);
  const [error, setError] = useState('');
  const [suggestions, setSuggestions] = useState([]);

  useEffect(() => { api.onUnauthorized = onLogout; }, [onLogout]);

  useEffect(() => { api.list().then(setTasks).catch((e) => setError(e.message)); }, []);

  const replace = (t) => setTasks((all) => all.map((x) => (x.id === t.id ? t : x)));

  async function run(key, fn) {
    setBusy(key); setError('');
    try { await fn(); } catch (e) { setError(e.message); } finally { setBusy(null); }
  }

  // Plain add, or AI add: the model turns a sentence into title, priority and due date.
  const add = (useAI) => run('add', async () => {
    if (!text.trim()) return;
    const fields = useAI ? await api.parse(text) : { title: text };
    const task = await api.create(fields);
    setTasks((all) => [task, ...all]);
    setText('');
  });

  const suggest = () => run('suggest', async () => {
    setSuggestions((await api.suggest()).suggestions);
  });

  const accept = (title) => run('add', async () => {
    const task = await api.create({ title });
    setTasks((all) => [task, ...all]);
    setSuggestions((s) => s.filter((x) => x !== title));
  });

  const split = (task) => run(task.id, async () => {
    const { subtasks } = await api.breakdown(task.title);
    const items = subtasks.map((title) => ({ id: crypto.randomUUID(), title, done: false }));
    replace(await api.update(task.id, { subtasks: [...task.subtasks, ...items] }));
  });

  const toggleSub = async (task, id) =>
    replace(await api.update(task.id, {
      subtasks: task.subtasks.map((s) => (s.id === id ? { ...s, done: !s.done } : s)),
    }));

  const visible = tasks.filter((t) => filter === 'all' || (filter === 'done') === t.done);

  return (
    <main>
      <header className="top">
        <h1>Taskwise</h1>
        <span className="who">{user.email}</span>
        <button onClick={onLogout}>Sign out</button>
      </header>
      <p className="sub">Type it the way you'd say it. The AI sorts out the details.</p>

      <div className="add">
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && add(true)}
          placeholder="Send Sam the budget by Friday, it's urgent"
          aria-label="New task"
        />
        <button className="primary" disabled={busy === 'add'} onClick={() => add(true)}>
          {busy === 'add' ? 'Adding…' : 'Add with AI'}
        </button>
        <button onClick={() => add(false)} disabled={busy === 'add'}>Add as typed</button>
        <button onClick={suggest} disabled={busy === 'suggest'}>
          {busy === 'suggest' ? 'Thinking…' : 'Suggest tasks'}
        </button>
      </div>

      {suggestions.length > 0 && (
        <div className="chips" aria-label="Suggested tasks">
          {suggestions.map((s) => (
            <button key={s} onClick={() => accept(s)}>+ {s}</button>
          ))}
        </div>
      )}

      {error && <p role="alert" className="error">{error}</p>}

      <div className="filters">
        {FILTERS.map((f) => (
          <button key={f} className={f === filter ? 'on' : ''} onClick={() => setFilter(f)}>{f}</button>
        ))}
      </div>

      {visible.length === 0 && <p className="empty">Nothing here yet. Add your first task above.</p>}

      <ul>
        {visible.map((t) => (
          <li key={t.id} className={`p-${t.priority}`}>
            <div className="row">
              <input type="checkbox" checked={t.done} aria-label={`Complete ${t.title}`}
                onChange={async () => replace(await api.update(t.id, { done: !t.done }))} />
              <span className={t.done ? 'title done' : 'title'}>{t.title}</span>
              {t.due && <span className="due">{t.due}</span>}
              <span className="badge">{t.priority}</span>
            </div>
            {t.subtasks.length > 0 && (
              <ul className="subs">
                {t.subtasks.map((s) => (
                  <li key={s.id}>
                    <label>
                      <input type="checkbox" checked={s.done} onChange={() => toggleSub(t, s.id)} />
                      <span className={s.done ? 'done' : ''}>{s.title}</span>
                    </label>
                  </li>
                ))}
              </ul>
            )}
            <div className="actions">
              <button onClick={() => split(t)} disabled={busy === t.id}>
                {busy === t.id ? 'Splitting…' : 'Split into steps'}
              </button>
              <button onClick={async () => { await api.remove(t.id); setTasks((a) => a.filter((x) => x.id !== t.id)); }}>
                Delete
              </button>
            </div>
          </li>
        ))}
      </ul>
    </main>
  );
}
