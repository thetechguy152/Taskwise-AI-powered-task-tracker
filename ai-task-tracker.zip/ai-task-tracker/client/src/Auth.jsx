import { useState } from 'react';
import { api } from './api.js';

export default function Auth({ onAuth }) {
  const [mode, setMode] = useState('register');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const signingUp = mode === 'register';

  async function submit(e) {
    e.preventDefault();
    setBusy(true); setError('');
    try { onAuth(await api[mode]({ email, password })); }
    catch (err) { setError(err.message); }
    finally { setBusy(false); }
  }

  return (
    <main className="auth">
      <h1>Taskwise</h1>
      <p className="sub">{signingUp ? 'Create an account to keep your tasks.' : 'Sign in to see your tasks.'}</p>
      <form onSubmit={submit}>
        <label>Email
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)}
            autoComplete="email" required />
        </label>
        <label>Password
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)}
            autoComplete={signingUp ? 'new-password' : 'current-password'} minLength={signingUp ? 8 : undefined} required />
          {signingUp && <small>At least 8 characters</small>}
        </label>
        {error && <p role="alert" className="error">{error}</p>}
        <button className="primary" disabled={busy}>
          {busy ? 'One moment…' : signingUp ? 'Create account' : 'Sign in'}
        </button>
      </form>
      <button className="link" onClick={() => { setMode(signingUp ? 'login' : 'register'); setError(''); }}>
        {signingUp ? 'Already have an account? Sign in' : 'New here? Create an account'}
      </button>
    </main>
  );
}
