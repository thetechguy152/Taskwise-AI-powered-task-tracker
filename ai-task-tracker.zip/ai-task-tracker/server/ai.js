const API = 'https://api.anthropic.com/v1/messages';

async function ask(system, user) {
  const res = await fetch(API, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-api-key': process.env.ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5',
      max_tokens: 500,
      system: system + ' Reply with JSON only, no markdown.',
      messages: [{ role: 'user', content: user }],
    }),
  });
  if (!res.ok) throw new Error(`AI request failed (${res.status})`);
  const data = await res.json();
  const text = data.content.map((b) => b.text || '').join('');
  return JSON.parse(text.replace(/```json|```/g, '').trim());
}

// "email Sam the budget by friday, urgent" -> { title, priority, due }
export function parseTask(text) {
  const today = new Date().toISOString().slice(0, 10);
  return ask(
    `Turn a casual sentence into a task. Today is ${today}. ` +
      'Return {"title": string, "priority": "low"|"medium"|"high", "due": "YYYY-MM-DD" or null}.',
    text
  );
}

// "Plan a launch" -> { subtasks: ["...", "..."] }
export function breakDown(title) {
  return ask(
    'Break a task into 3 to 6 concrete, short subtasks. Return {"subtasks": string[]}.',
    title
  );
}

// Open task titles -> { suggestions: ["...", "..."] }
export function suggestTasks(titles) {
  return ask(
    'Given the user\'s open tasks, suggest 3 useful tasks they may be missing. ' +
      'Keep each under 8 words. Return {"suggestions": string[]}.',
    titles.join('\n') || 'No tasks yet'
  );
}
