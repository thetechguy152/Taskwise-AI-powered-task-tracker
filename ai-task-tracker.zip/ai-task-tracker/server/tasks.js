import { randomUUID } from 'node:crypto';
import { pool } from './db.js';

const cleanDue = (d) => (typeof d === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(d) ? d : null);
const cleanPriority = (p) => (['low', 'medium', 'high'].includes(p) ? p : 'medium');
const cleanTitle = (t) => String(t).trim().slice(0, 255);

async function withTx(fn) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const result = await fn(conn);
    await conn.commit();
    return result;
  } catch (e) {
    await conn.rollback();
    throw e;
  } finally {
    conn.release();
  }
}

// Accepts subtasks as strings or { title, done } objects.
async function insertSubtasks(conn, taskId, subtasks = []) {
  const rows = subtasks
    .map((s) => ({ title: typeof s === 'string' ? s : s?.title, done: typeof s === 'object' && !!s?.done }))
    .filter((s) => s.title && String(s.title).trim())
    .map((s, i) => [randomUUID(), taskId, cleanTitle(s.title), s.done, i]);
  if (rows.length) {
    await conn.query('INSERT INTO subtasks (id, task_id, title, done, position) VALUES ?', [rows]);
  }
}

const shape = (t, subs) => ({
  id: t.id,
  title: t.title,
  priority: t.priority,
  due: t.due,
  done: !!t.done,
  subtasks: subs
    .filter((s) => s.task_id === t.id)
    .map((s) => ({ id: s.id, title: s.title, done: !!s.done })),
});

export async function list(userId) {
  const [tasks] = await pool.query('SELECT * FROM tasks WHERE user_id = ? ORDER BY created_at DESC', [userId]);
  if (!tasks.length) return [];
  const [subs] = await pool.query(
    'SELECT * FROM subtasks WHERE task_id IN (?) ORDER BY position',
    [tasks.map((t) => t.id)]
  );
  return tasks.map((t) => shape(t, subs));
}

export async function get(userId, id) {
  const [rows] = await pool.query('SELECT * FROM tasks WHERE id = ? AND user_id = ?', [id, userId]);
  if (!rows[0]) return null;
  const [subs] = await pool.query('SELECT * FROM subtasks WHERE task_id = ? ORDER BY position', [id]);
  return shape(rows[0], subs);
}

export async function create(userId, { title, priority, due, subtasks }) {
  const id = randomUUID();
  await withTx(async (conn) => {
    await conn.query(
      'INSERT INTO tasks (id, user_id, title, priority, due) VALUES (?, ?, ?, ?, ?)',
      [id, userId, cleanTitle(title), cleanPriority(priority), cleanDue(due)]
    );
    await insertSubtasks(conn, id, subtasks);
  });
  return get(userId, id);
}

export async function update(userId, id, patch) {
  if (!(await get(userId, id))) return null;
  const sets = [];
  const vals = [];
  if (typeof patch.title === 'string' && patch.title.trim()) { sets.push('title = ?'); vals.push(cleanTitle(patch.title)); }
  if ('priority' in patch) { sets.push('priority = ?'); vals.push(cleanPriority(patch.priority)); }
  if ('due' in patch) { sets.push('due = ?'); vals.push(cleanDue(patch.due)); }
  if ('done' in patch) { sets.push('done = ?'); vals.push(!!patch.done); }

  await withTx(async (conn) => {
    if (sets.length) await conn.query(`UPDATE tasks SET ${sets.join(', ')} WHERE id = ?`, [...vals, id]);
    if (Array.isArray(patch.subtasks)) {
      await conn.query('DELETE FROM subtasks WHERE task_id = ?', [id]);
      await insertSubtasks(conn, id, patch.subtasks);
    }
  });
  return get(userId, id);
}

export async function remove(userId, id) {
  await pool.query('DELETE FROM tasks WHERE id = ? AND user_id = ?', [id, userId]);
}
