import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import { randomUUID } from 'node:crypto';
import { pool, initSchema } from './db.js';
import { sign, requireAuth } from './auth.js';
import * as tasks from './tasks.js';
import { parseTask, breakDown, suggestTasks } from './ai.js';

if (!process.env.JWT_SECRET) throw new Error('Set JWT_SECRET in server/.env');

const app = express();
app.use(cors(), express.json());

// Express 4 doesn't catch rejected promises, so wrap async handlers.
const wrap = (fn) => (req, res) =>
  fn(req, res).catch((e) => {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  });

// ---------- Auth ----------
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function credentials(req, res, checkRules) {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  if (checkRules && !EMAIL.test(email)) { res.status(400).json({ error: 'Enter a valid email' }); return null; }
  if (checkRules && password.length < 8) { res.status(400).json({ error: 'Password must be at least 8 characters' }); return null; }
  if (!email || !password) { res.status(400).json({ error: 'Email and password are required' }); return null; }
  return { email, password };
}

app.post('/api/auth/register', wrap(async (req, res) => {
  const c = credentials(req, res, true);
  if (!c) return;
  const user = { id: randomUUID(), email: c.email };
  try {
    await pool.query('INSERT INTO users (id, email, password_hash) VALUES (?, ?, ?)',
      [user.id, user.email, await bcrypt.hash(c.password, 10)]);
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'That email is already registered' });
    throw e;
  }
  res.status(201).json({ token: sign(user), user });
}));

app.post('/api/auth/login', wrap(async (req, res) => {
  const c = credentials(req, res, false);
  if (!c) return;
  const [rows] = await pool.query('SELECT id, email, password_hash FROM users WHERE email = ?', [c.email]);
  const u = rows[0];
  if (!u || !(await bcrypt.compare(c.password, u.password_hash))) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }
  res.json({ token: sign(u), user: { id: u.id, email: u.email } });
}));

app.get('/api/auth/me', requireAuth, wrap(async (req, res) => {
  const [rows] = await pool.query('SELECT id, email FROM users WHERE id = ?', [req.userId]);
  if (!rows[0]) return res.status(401).json({ error: 'Please sign in' });
  res.json({ user: rows[0] });
}));

// ---------- Tasks (signed-in users only, scoped to their own rows) ----------
app.use('/api/tasks', requireAuth);
app.use('/api/ai', requireAuth);

app.get('/api/tasks', wrap(async (req, res) => res.json(await tasks.list(req.userId))));

app.post('/api/tasks', wrap(async (req, res) => {
  if (!req.body.title?.trim()) return res.status(400).json({ error: 'Title is required' });
  res.status(201).json(await tasks.create(req.userId, req.body));
}));

app.patch('/api/tasks/:id', wrap(async (req, res) => {
  const task = await tasks.update(req.userId, req.params.id, req.body);
  if (!task) return res.status(404).json({ error: 'Task not found' });
  res.json(task);
}));

app.delete('/api/tasks/:id', wrap(async (req, res) => {
  await tasks.remove(req.userId, req.params.id);
  res.status(204).end();
}));

// ---------- AI ----------
const aiRoute = (fn, field) => async (req, res) => {
  if (!req.body[field]?.trim()) return res.status(400).json({ error: `${field} is required` });
  try { res.json(await fn(req.body[field])); }
  catch (e) { res.status(502).json({ error: e.message }); }
};
app.post('/api/ai/parse', aiRoute(parseTask, 'text'));
app.post('/api/ai/breakdown', aiRoute(breakDown, 'title'));

app.post('/api/ai/suggest', async (req, res) => {
  try {
    const open = (await tasks.list(req.userId)).filter((t) => !t.done).map((t) => t.title);
    res.json(await suggestTasks(open));
  } catch (e) { res.status(502).json({ error: e.message }); }
});

await initSchema();
app.listen(process.env.PORT || 3001, () => console.log('API running'));
