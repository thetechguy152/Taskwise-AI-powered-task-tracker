import jwt from 'jsonwebtoken';

export const sign = (user) =>
  jwt.sign({ sub: user.id }, process.env.JWT_SECRET, { expiresIn: '7d' });

export function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  try {
    req.userId = jwt.verify(header.replace(/^Bearer /, ''), process.env.JWT_SECRET).sub;
    next();
  } catch {
    res.status(401).json({ error: 'Please sign in' });
  }
}
